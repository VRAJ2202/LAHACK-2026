"""
SpecMem LLM service — Gemini debugging agent with token savings.
"""

from specmem.backend.retrieval_service import get_client, retrieve_similar_bugs, detect_failed_fix
from specmem.backend.memory_service import save_token_log, list_bug_memories


def count_tokens(text: str) -> int:
    return max(1, len(text) // 4)


def calculate_token_savings(raw_context: str, specmem_context: str) -> dict:
    # before = full unfiltered memory dump (naive approach)
    # after  = focused SpecMem prompt (only relevant memories)
    before = count_tokens(raw_context)
    after = count_tokens(specmem_context)
    savings_pct = round((1 - after / max(before, 1)) * 100, 2)
    return {
        "before_tokens": before,
        "after_tokens": after,
        "savings_percent": savings_pct,
    }


def build_debug_prompt(
    query: str,
    similar_bugs: list[dict],
    failed_match: dict | None,
    confidence: float,
) -> str:
    lines = [
        "You are SpecMem, a memory-powered debugging assistant.",
        "You have access to the project's past bug history.",
        "",
        f"## Current Bug / Query\n{query}",
        "",
    ]

    if similar_bugs:
        lines.append("## Similar Past Bugs (from memory)")
        for i, bug in enumerate(similar_bugs, 1):
            lines.append(f"\n### Bug {i}: {bug.get('bug_title', 'Unknown')}")
            lines.append(f"- File: {bug.get('file_path', 'N/A')} | Module: {bug.get('module', 'N/A')}")
            lines.append(f"- Description: {bug.get('description', '')}")
            lines.append(f"- Root cause: {bug.get('root_cause', '')}")
            lines.append(f"- Final fix: {bug.get('final_fix', '')}")
            if bug.get("failed_fixes"):
                lines.append(f"- FAILED approaches: {', '.join(bug['failed_fixes'])}")

    if failed_match:
        pct = int(confidence * 100)
        example_ff = failed_match.get("failed_fixes", ["unknown"])[-1]
        lines.append(
            f"\n## WARNING — Previously Failed Fix ({pct}% similarity match)\n"
            f"This approach is {pct}% similar to a fix that already failed in "
            f"**'{failed_match.get('bug_title', 'a past bug')}'**.\n"
            f"Example of what failed: \"{example_ff}\"\n"
            "DO NOT recommend this approach."
        )

    lines += [
        "",
        "## Your Task",
        "1. Summarize what this bug likely is based on memory.",
        "2. Explicitly warn about failed approaches.",
        "3. Recommend the best fix based on past experience.",
        "4. Mention which files/modules are likely involved.",
        "5. Be concise and actionable.",
    ]

    return "\n".join(lines)


def generate_debug_response(
    project_id: str,
    query: str,
    module: str | None = None,
    file_path: str | None = None,
) -> dict:
    similar_bugs, retrieval_mode = retrieve_similar_bugs(
        project_id=project_id,
        query=query,
        module=module,
        file_path=file_path,
        limit=5,
    )

    failed_match, confidence = detect_failed_fix(
        project_id=project_id,
        proposed_fix=query,
        module=module,
    )

    prompt = build_debug_prompt(query, similar_bugs, failed_match, confidence)

    # Token savings: before = full project memory dump, after = focused prompt
    all_memories = list_bug_memories(project_id, limit=100)
    raw_context = f"Project: {project_id}\nQuery: {query}\n" + "\n".join(
        " | ".join(str(v) for v in m.values()) for m in all_memories
    )
    token_savings = calculate_token_savings(raw_context, prompt)

    try:
        response = get_client().models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
        )
        answer = response.text
    except Exception as e:
        answer = (
            f"[Gemini unavailable: {e}]\n\nTop matches from memory:\n"
            + "\n".join(
                f"- {b.get('bug_title')}: {b.get('final_fix', 'No fix recorded')}"
                for b in similar_bugs
            )
        )

    try:
        save_token_log(
            project_id=project_id,
            query=query,
            before_tokens=token_savings["before_tokens"],
            after_tokens=token_savings["after_tokens"],
        )
    except Exception:
        pass

    # Build human-readable warning with confidence
    failed_fix_warning_str: str | None = None
    if failed_match and confidence > 0:
        pct = int(confidence * 100)
        example_ff = failed_match.get("failed_fixes", ["unknown"])[-1]
        failed_fix_warning_str = (
            f"This fix is {pct}% similar to a previously failed fix in "
            f"'{failed_match.get('bug_title', 'a past bug')}'. "
            f"Avoid: \"{example_ff}\""
        )

    return {
        "answer": answer,
        "similar_bugs": similar_bugs,
        "failed_fix_warning": failed_fix_warning_str,
        "failed_fix_confidence": confidence if failed_match else None,
        "retrieval_mode": retrieval_mode,
        "token_savings": token_savings,
    }


def extract_bug_memory(project_id: str, raw_text: str) -> dict:
    """Use Gemini to extract structured bug memory fields from raw text."""
    import json

    prompt = f"""You are a bug memory extractor. Extract structured information from the text below and return ONLY a valid JSON object — no markdown, no explanation.

Text:
{raw_text}

Return this exact JSON structure:
{{
  "project_id": "{project_id}",
  "bug_title": "short descriptive title",
  "description": "what the bug is",
  "file_path": "file path if mentioned, else empty string",
  "module": "module or component if mentioned, else empty string",
  "failed_fixes": ["list of approaches that did not work"],
  "root_cause": "root cause if mentioned, else empty string",
  "final_fix": "the solution if mentioned, else empty string",
  "tags": ["relevant", "tags"]
}}"""

    response = get_client().models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt,
    )
    text = response.text.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    return json.loads(text)
